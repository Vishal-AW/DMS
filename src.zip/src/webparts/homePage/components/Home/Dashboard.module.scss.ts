
require("./Dashboard.module.css");
const styles = {
  'row1-container': 'row1-container_893bfb44',
  'card-container': 'card-container_893bfb44',
  'card-content': 'card-content_893bfb44',
  'card-image': 'card-image_893bfb44',
  'card-details': 'card-details_893bfb44',
  'card-title': 'card-title_893bfb44',
  'card-link': 'card-link_893bfb44',
  'fa-arrow-right': 'fa-arrow-right_893bfb44',
  'card-overlay': 'card-overlay_893bfb44',
  'arrow-button': 'arrow-button_893bfb44',
  dashcards: 'dashcards_893bfb44',
  dashcard: 'dashcard_893bfb44',
  dashcard__image: 'dashcard__image_893bfb44',
  dashcard__overlay: 'dashcard__overlay_893bfb44',
  dashcard__header: 'dashcard__header_893bfb44',
  dashcard__arc: 'dashcard__arc_893bfb44',
  dashcard__thumb: 'dashcard__thumb_893bfb44',
  dashcard__title: 'dashcard__title_893bfb44',
  dashcard__tagline: 'dashcard__tagline_893bfb44',
  dashcard__status: 'dashcard__status_893bfb44',
  dashcard__description: 'dashcard__description_893bfb44',
  grid: 'grid_893bfb44',
  row: 'row_893bfb44',
  col3: 'col3_893bfb44',
  'ms-Grid': 'ms-Grid_893bfb44'
};

export default styles;
