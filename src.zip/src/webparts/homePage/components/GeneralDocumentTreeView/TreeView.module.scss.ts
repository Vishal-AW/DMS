
require("./TreeView.module.css");
const styles = {
  'tree-view': 'tree-view_8da248c6',
  'node-name': 'node-name_8da248c6',
  'tree-node': 'tree-node_8da248c6',
  'folder-icon': 'folder-icon_8da248c6',
  'toggle-button': 'toggle-button_8da248c6',
  grid: 'grid_8da248c6',
  row: 'row_8da248c6',
  col2: 'col2_8da248c6',
  'ms-Grid': 'ms-Grid_8da248c6',
  col3: 'col3_8da248c6',
  col9: 'col9_8da248c6',
  col6: 'col6_8da248c6',
  col10: 'col10_8da248c6',
  col12: 'col12_8da248c6',
  iFrameDialog: 'iFrameDialog_8da248c6',
  spinnerContainer: 'spinnerContainer_8da248c6',
  permissionDescription: 'permissionDescription_8da248c6',
  table: 'table_8da248c6',
  folderTile: 'folderTile_8da248c6',
  folderLabel: 'folderLabel_8da248c6',
  'primary-btn': 'primary-btn_8da248c6',
  'light-btn': 'light-btn_8da248c6',
  'secondary-btn': 'secondary-btn_8da248c6',
  'info-btn': 'info-btn_8da248c6',
  customHrdot: 'customHrdot_8da248c6',
  Headerlabel: 'Headerlabel_8da248c6',
  btnDanger: 'btnDanger_8da248c6'
};

export default styles;
