
require("./HomePage.module.css");
const styles = {
  homePage: 'homePage_0f5a47d5',
  teams: 'teams_0f5a47d5',
  welcome: 'welcome_0f5a47d5',
  welcomeImage: 'welcomeImage_0f5a47d5',
  sitebar: 'sitebar_0f5a47d5',
  links: 'links_0f5a47d5',
  asidelogo: 'asidelogo_0f5a47d5',
  footera: 'footera_0f5a47d5',
  heart: 'heart_0f5a47d5',
  modal: 'modal_0f5a47d5'
};

export default styles;
