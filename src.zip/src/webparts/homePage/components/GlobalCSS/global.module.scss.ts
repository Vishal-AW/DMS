
require("./global.module.css");
const styles = {
  wrapper: 'wrapper_594b72e7',
  content: 'content_594b72e7',
  j_b_ada2ac09: 'j_b_ada2ac09_594b72e7',
  header: 'header_594b72e7',
  headerdiv: 'headerdiv_594b72e7',
  topnavright: 'topnavright_594b72e7',
  sh: 'sh_594b72e7',
  system: 'system_594b72e7',
  headerdropdown: 'headerdropdown_594b72e7',
  headericon: 'headericon_594b72e7',
  nav: 'nav_594b72e7',
  article: 'article_594b72e7',
  footer: 'footer_594b72e7',
  userProfile: 'userProfile_594b72e7',
  profileIcon: 'profileIcon_594b72e7',
  profileName: 'profileName_594b72e7',
  dropdownMenu: 'dropdownMenu_594b72e7',
  dropdownItem: 'dropdownItem_594b72e7'
};

export default styles;
