

export class ConstName {

    public static readonly Const_Route = {
        Dashboard: "Dashboard",
        Master: "/Master"
    }


    public static readonly Const_ListName = {
        Dashboard: "Dashboard",
        Master: "/Master"
    }







}