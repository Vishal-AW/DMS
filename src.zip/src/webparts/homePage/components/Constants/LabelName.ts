export class LabelName {

    public static readonly LabelName={
        Dashboard : "Dashboard",
        Master : "Master",
    }


}