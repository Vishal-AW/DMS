
require("./Common.module.css");
const styles = {
  popupBody: 'popupBody_3c45041f',
  bs_j_ada2ac09: 'bs_j_ada2ac09_3c45041f',
  popupHead: 'popupHead_3c45041f',
  close: 'close_3c45041f',
  closeBtn: 'closeBtn_3c45041f',
  primaryButton: 'primaryButton_3c45041f'
};

export default styles;
