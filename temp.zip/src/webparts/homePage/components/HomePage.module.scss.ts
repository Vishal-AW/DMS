
require("./HomePage.module.css");
const styles = {
  homePage: 'homePage_1fc41b0c',
  teams: 'teams_1fc41b0c',
  welcome: 'welcome_1fc41b0c',
  welcomeImage: 'welcomeImage_1fc41b0c',
  sitebar: 'sitebar_1fc41b0c',
  links: 'links_1fc41b0c',
  asidelogo: 'asidelogo_1fc41b0c',
  footera: 'footera_1fc41b0c',
  modal: 'modal_1fc41b0c'
};

export default styles;
