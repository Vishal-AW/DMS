
require("./Dashboard.module.css");
const styles = {
  'row1-container': 'row1-container_147f482e',
  'card-container': 'card-container_147f482e',
  'card-content': 'card-content_147f482e',
  'card-image': 'card-image_147f482e',
  'card-details': 'card-details_147f482e',
  'card-title': 'card-title_147f482e',
  'card-link': 'card-link_147f482e',
  'fa-arrow-right': 'fa-arrow-right_147f482e',
  'card-overlay': 'card-overlay_147f482e',
  'arrow-button': 'arrow-button_147f482e'
};

export default styles;
