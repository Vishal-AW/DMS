
require("./TreeView.module.css");
const styles = {
  'tree-view': 'tree-view_2b2fb144',
  'node-name': 'node-name_2b2fb144',
  'tree-node': 'tree-node_2b2fb144',
  'folder-icon': 'folder-icon_2b2fb144',
  'toggle-button': 'toggle-button_2b2fb144',
  grid: 'grid_2b2fb144',
  col2: 'col2_2b2fb144',
  'ms-Grid': 'ms-Grid_2b2fb144',
  row: 'row_2b2fb144',
  col6: 'col6_2b2fb144',
  col10: 'col10_2b2fb144',
  col12: 'col12_2b2fb144',
  iFrameDialog: 'iFrameDialog_2b2fb144',
  spinnerContainer: 'spinnerContainer_2b2fb144',
  permissionDescription: 'permissionDescription_2b2fb144',
  table: 'table_2b2fb144',
  'sub-btn': 'sub-btn_2b2fb144',
  'can-btn': 'can-btn_2b2fb144'
};

export default styles;
