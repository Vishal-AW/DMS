
require("./AppCustomizer.module.css");
const styles = {
  'top-sub-nav': 'top-sub-nav_e56a76f3',
  'main-menu': 'main-menu_e56a76f3',
  'menu-item': 'menu-item_e56a76f3',
  setIcon: 'setIcon_e56a76f3',
  'sub-menu': 'sub-menu_e56a76f3',
  'sub-menu-item': 'sub-menu-item_e56a76f3'
};

export default styles;
