
require("./global.module.css");
const styles = {
  wrapper: 'wrapper_eb2a15c7',
  content: 'content_eb2a15c7',
  header: 'header_eb2a15c7',
  headerdiv: 'headerdiv_eb2a15c7',
  topnavright: 'topnavright_eb2a15c7',
  sh: 'sh_eb2a15c7',
  system: 'system_eb2a15c7',
  headerdropdown: 'headerdropdown_eb2a15c7',
  headericon: 'headericon_eb2a15c7',
  nav: 'nav_eb2a15c7',
  article: 'article_eb2a15c7',
  footer: 'footer_eb2a15c7',
  userProfile: 'userProfile_eb2a15c7',
  profileIcon: 'profileIcon_eb2a15c7',
  profileName: 'profileName_eb2a15c7',
  dropdownMenu: 'dropdownMenu_eb2a15c7',
  dropdownItem: 'dropdownItem_eb2a15c7'
};

export default styles;
