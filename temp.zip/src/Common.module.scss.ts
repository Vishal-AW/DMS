
require("./Common.module.css");
const styles = {
  popupBody: 'popupBody_45f4306f',
  popupHead: 'popupHead_45f4306f',
  close: 'close_45f4306f',
  closeBtn: 'closeBtn_45f4306f',
  primaryButton: 'primaryButton_45f4306f'
};

export default styles;
