import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare const FolderStructure: (context: WebPartContext, FolderPath: string, uid: number[], LibraryName: string) => Promise<any>;
//# sourceMappingURL=FolderStructure.d.ts.map