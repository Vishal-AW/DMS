import { SPHttpClient } from '@microsoft/sp-http';
export declare function GetAllProject(WebUrl: string, spHttpClient: SPHttpClient): Promise<any>;
export declare function GetProjectItemByID(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function SaveProjectMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateProjectMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=TypeOfProjectService.d.ts.map