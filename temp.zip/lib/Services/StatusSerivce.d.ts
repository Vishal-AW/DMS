export declare function GetAllStatus(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function getStatusByInternalStatus(WebUrl: string, spHttpClient: any, internalStatus: string): Promise<any>;
export declare function SaveStateMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateStateMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=StatusSerivce.d.ts.map