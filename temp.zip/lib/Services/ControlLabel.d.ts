import { SPHttpClient } from '@microsoft/sp-http';
import { ILabel } from "../webparts/homePage/components/Interface/ILabel";
export declare function GetAllLabel(WebUrl: string, spHttpClient: SPHttpClient, Language: string): Promise<ILabel>;
export declare function SaveDocumentTypeMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateDocumentTypeMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=ControlLabel.d.ts.map