export declare function GetAllState(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function GetStateItemByID(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function SaveStateMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateStateMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=StateService.d.ts.map