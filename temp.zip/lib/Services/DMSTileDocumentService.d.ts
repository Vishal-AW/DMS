import { SPHttpClient } from '@microsoft/sp-http-base';
export declare function UploadDocument(WebUrl: any, spHttpClient: any, file: any, filename: any, savedata: any): void;
export declare function GetAttachmentFile(WebUrl: any, spHttpClient: any, ID: string): Promise<any>;
export declare function DeleteData(WebUrl: string, spHttpClient: SPHttpClient, LID: Number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=DMSTileDocumentService.d.ts.map