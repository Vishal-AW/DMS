export declare function getActiveTypeData(WebUrl: string, spHttpClient: any, PSType: string): Promise<any>;
//# sourceMappingURL=PrefixSuffixMasterService.d.ts.map