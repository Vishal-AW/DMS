export declare function GetAllSector(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function GetSectorItemByID(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function SaveSectorMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateSectorMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=SectorService.d.ts.map