export declare function getAllNav(WebUrl: string, spHttpClient: any, EmailId: any): Promise<any>;
//# sourceMappingURL=NavigationService.d.ts.map