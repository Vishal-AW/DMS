export declare function getConfig(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function getConfigActive(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function getConfidDataByID(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function SaveconfigMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateconfigMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=ConfigService.d.ts.map