export declare function getArchiveDaysDetails(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function getRedundancyDaysByID(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function getActiveRedundancyDays(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function SaveGeography(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateGeography(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=ArchiveRedundancyService.d.ts.map