export declare function getArchiveDaysDetails(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function getRedundancyDaysByID(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function getActiveRedundancyDays(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function SaveClassificationMaster(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateClassificationMaster(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=ArchiveRedundancyDaysService.d.ts.map