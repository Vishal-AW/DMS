import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare function getAllFolder(WebUrl: string, context: WebPartContext, FolderName: string): Promise<any>;
export declare function getPermission(url: string, context: WebPartContext): Promise<any>;
export declare function commonPostMethod(url: string, context: WebPartContext): Promise<SPHttpClientResponse | undefined>;
export declare function getListData(url: string, context: WebPartContext): Promise<any>;
export declare function updateLibrary(WebUrl: string, spHttpClient: SPHttpClient, metaData: any, Id: number, listName: string): Promise<SPHttpClientResponse | undefined>;
export declare function UploadFile(WebUrl: string, spHttpClient: any, file: string, DisplayName: string | File, DocumentLib: string, jsonBody: {
    __metadata: {
        type: string;
    };
    Name: string;
    TileLID: any;
    DocumentType: string;
    Documentpath: string;
} | null, FolderPath: string): Promise<any>;
export declare function getApprovalData(context: WebPartContext, libeName: string, useremail: string): Promise<any>;
export declare function getDocument(WebUrl: string, spHttpClient: any, filter: any, libName: string): Promise<any>;
//# sourceMappingURL=GeneralDocument.d.ts.map