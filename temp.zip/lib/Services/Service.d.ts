import { WebPartContext } from "@microsoft/sp-webpart-base";
export declare class service {
    private count;
    private ListGuid;
    private required;
    private defaulttViewID;
    props: any;
    CreateList(context: WebPartContext, webURL: string, IListItem: [], TileLID: number, isArchive: boolean): void;
    private httpServiceForCreateList;
    ArchieveCreateList(context: WebPartContext, webURL: string, IListItem: []): void;
    private ArchievehttpServiceForCreateList;
    private createAllColumns;
    private GetListData;
    private Createlookup;
    private CreateChoiceCloumn;
    private createColumn;
    getAllRequiredFields(context: WebPartContext, webURL: string, IListItem: []): Promise<void>;
    private callUpdatefunction;
    private updateColumn;
    getDefaultView(context: WebPartContext, webURL: string, IListItem: []): Promise<void>;
    private addColumnOnView;
    private addDefaultViewColumn;
}
//# sourceMappingURL=Service.d.ts.map