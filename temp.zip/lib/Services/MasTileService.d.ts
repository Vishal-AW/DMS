import { SPHttpClient } from '@microsoft/sp-http';
export declare function getTileAllData(WebUrl: string, spHttpClient: SPHttpClient): Promise<any>;
export declare function getDataById(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function getAllActiveTileData(WebUrl: string, spHttpClient: any): Promise<any>;
export declare function getTileAdmin(WebUrl: string, spHttpClient: any, ID: number): Promise<any>;
export declare function getDataByLibraryName(WebUrl: string, spHttpClient: any, name: any): Promise<any>;
export declare function SaveTileSetting(WebUrl: string, spHttpClient: any, savedata: any): Promise<any>;
export declare function UpdateTileSetting(WebUrl: string, spHttpClient: any, savedata: any, LID: number): Promise<import("@microsoft/sp-http-base").SPHttpClientResponse | undefined>;
//# sourceMappingURL=MasTileService.d.ts.map