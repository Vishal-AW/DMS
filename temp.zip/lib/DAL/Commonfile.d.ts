import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { WebPartContext } from '@microsoft/sp-webpart-base';
export declare function getUSERID(WebUrl: string, spHttpClient: SPHttpClient, username: any): Promise<any>;
export declare function GetListItem(WebUrl: string, spHttpClient: SPHttpClient, ListName: string, options: any): Promise<any>;
export declare function CreateItem(WebUrl: string, spHttpClient: SPHttpClient, ListName: string, jsonBody: any): Promise<any>;
export declare function UpdateItem(WebUrl: string, spHttpClient: SPHttpClient, ListName: string, jsonBody: any, ID: Number): Promise<SPHttpClientResponse | undefined>;
export declare function getUserIdFromLoginName(context: WebPartContext, loginName: string): Promise<any>;
export declare function UploadFile(WebUrl: string, spHttpClient: any, file: string, DisplayName: string | File, DocumentLib: string, jsonBody: {
    __metadata: {
        type: string;
    };
    Name: string;
    TileLID: any;
    DocumentType: string;
    Documentpath: string;
} | null): Promise<any>;
export declare function UpdateFileItem(context: WebPartContext, webURL: string, ListName: string, jsonBody: any, ID: Number): Promise<SPHttpClientResponse | undefined>;
export declare function uuidv4(): Promise<string>;
export declare function DeleteItem(WebUrl: string, spHttpClient: SPHttpClient, ListName: string, ID: Number): Promise<SPHttpClientResponse | undefined>;
export declare function FindUserGroup(context: WebPartContext, loginName: string): Promise<any>;
//# sourceMappingURL=Commonfile.d.ts.map