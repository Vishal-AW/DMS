import { WebPartContext } from "@microsoft/sp-webpart-base";
import { SPHttpClientResponse } from '@microsoft/sp-http';
export declare class HTTPServices {
    _getListItem(context: WebPartContext, webURL: string, ListName: string, option: string): Promise<any>;
    CreateItems(context: WebPartContext, webURL: string, ListName: string, jsonBody: any): Promise<any>;
    UpdateItem(context: WebPartContext, webURL: string, ListName: string, jsonBody: any, ID: Number): Promise<SPHttpClientResponse | undefined>;
    recursiveFunction(context: WebPartContext, url: string): Promise<any>;
    isMember(context: WebPartContext, GroupName: string): Promise<any>;
    getLink(context: WebPartContext): Promise<any>;
    UploadFile(context: WebPartContext, WebUrl: string, DocumentLib: string, file: any, DisplayName: string, jsonBody: any): Promise<void>;
    getUserInfo(context: WebPartContext, WebUrl: string): Promise<any>;
    uuidv4(): string;
    HideDesign(): void;
}
//# sourceMappingURL=HTTPServices.d.ts.map