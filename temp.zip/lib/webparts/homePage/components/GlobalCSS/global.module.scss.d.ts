declare const styles: {
    wrapper: string;
    content: string;
    header: string;
    headerdiv: string;
    topnavright: string;
    sh: string;
    system: string;
    headerdropdown: string;
    headericon: string;
    nav: string;
    article: string;
    footer: string;
    userProfile: string;
    profileIcon: string;
    profileName: string;
    dropdownMenu: string;
    dropdownItem: string;
};
export default styles;
//# sourceMappingURL=global.module.scss.d.ts.map