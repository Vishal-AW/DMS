import * as React from "react";
interface ISideMenu {
    onclickbutton: (value: boolean) => void;
    props: any;
}
declare const SideMenu: React.FC<ISideMenu>;
export default SideMenu;
//# sourceMappingURL=SideMenu.d.ts.map