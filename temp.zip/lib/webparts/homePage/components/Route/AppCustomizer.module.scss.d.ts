declare const styles: {
    'top-sub-nav': string;
    'main-menu': string;
    'menu-item': string;
    setIcon: string;
    'sub-menu': string;
    'sub-menu-item': string;
};
export default styles;
//# sourceMappingURL=AppCustomizer.module.scss.d.ts.map