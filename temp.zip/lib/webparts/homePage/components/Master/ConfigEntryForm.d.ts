/// <reference types="react" />
export default function ConfigMaster({ props }: any): JSX.Element;
//# sourceMappingURL=ConfigEntryForm.d.ts.map