/// <reference types="react" />
import 'bootstrap/dist/css/bootstrap.min.css';
export default function Master({ props }: any): JSX.Element;
//# sourceMappingURL=Master.d.ts.map