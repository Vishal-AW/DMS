import * as React from "react";
import { IconProps } from './types';
export declare const InkBottle: React.FC<IconProps>;
//# sourceMappingURL=InkBottle.d.ts.map