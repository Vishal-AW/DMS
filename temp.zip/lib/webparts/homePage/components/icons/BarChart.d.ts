import * as React from "react";
import { IconProps } from './types';
export declare const BarChart: React.FC<IconProps>;
//# sourceMappingURL=BarChart.d.ts.map