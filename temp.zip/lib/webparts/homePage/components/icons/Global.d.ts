import * as React from "react";
import { IconProps } from './types';
export declare const Global: React.FC<IconProps>;
//# sourceMappingURL=Global.d.ts.map