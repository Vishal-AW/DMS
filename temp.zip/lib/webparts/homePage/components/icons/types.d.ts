/// <reference types="react" />
export interface IconProps extends React.SVGAttributes<HTMLOrSVGElement> {
    size?: number;
}
//# sourceMappingURL=types.d.ts.map