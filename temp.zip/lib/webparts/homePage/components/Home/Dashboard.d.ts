/// <reference types="react" />
export default function Dashboard({ props }: any): JSX.Element;
//# sourceMappingURL=Dashboard.d.ts.map