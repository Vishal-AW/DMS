declare const styles: {
    'row1-container': string;
    'card-container': string;
    'card-content': string;
    'card-image': string;
    'card-details': string;
    'card-title': string;
    'card-link': string;
    'fa-arrow-right': string;
    'card-overlay': string;
    'arrow-button': string;
};
export default styles;
//# sourceMappingURL=Dashboard.module.scss.d.ts.map