/// <reference types="react" />
import type { IHomePageProps } from './IHomePageProps';
import '../components/Hidedesign.css';
export default function HomePage(props: IHomePageProps): JSX.Element;
//# sourceMappingURL=HomePage.d.ts.map