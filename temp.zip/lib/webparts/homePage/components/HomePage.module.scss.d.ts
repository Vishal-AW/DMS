declare const styles: {
    homePage: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    sitebar: string;
    links: string;
    asidelogo: string;
    footera: string;
    modal: string;
};
export default styles;
//# sourceMappingURL=HomePage.module.scss.d.ts.map