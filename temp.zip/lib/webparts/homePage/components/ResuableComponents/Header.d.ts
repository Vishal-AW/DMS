/// <reference types="react" />
export default function Header(): JSX.Element;
//# sourceMappingURL=Header.d.ts.map