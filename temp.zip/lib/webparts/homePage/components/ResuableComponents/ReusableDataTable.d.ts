import * as React from 'react';
import 'react-table-6/react-table.css';
export interface IReusableDataTableComponentProps {
    PagedefaultSize?: number;
    TableRows?: number;
    Tablecolumns?: any;
    Tabledata?: any;
    TableshowPagination?: boolean;
    TableshowFilter?: boolean;
    TableClassName?: string;
}
declare const ReusableDataTable: React.FC<IReusableDataTableComponentProps>;
export default ReusableDataTable;
//# sourceMappingURL=ReusableDataTable.d.ts.map