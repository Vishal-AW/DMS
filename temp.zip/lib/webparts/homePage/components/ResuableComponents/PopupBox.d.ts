import * as React from 'react';
interface IPopupboxProps {
    isPopupBoxVisible: boolean;
    hidePopup: () => void;
}
declare const _default: React.NamedExoticComponent<IPopupboxProps>;
export default _default;
interface IConfirmboxProps {
    hideDialog: boolean;
    closeDialog: () => void;
    handleConfirm: (value: boolean) => void;
    msg: string;
}
export declare const ConfirmationDialog: React.FC<IConfirmboxProps>;
//# sourceMappingURL=PopupBox.d.ts.map