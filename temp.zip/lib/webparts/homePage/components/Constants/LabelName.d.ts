export declare class LabelName {
    static readonly LabelName: {
        Dashboard: string;
        Master: string;
    };
}
//# sourceMappingURL=LabelName.d.ts.map