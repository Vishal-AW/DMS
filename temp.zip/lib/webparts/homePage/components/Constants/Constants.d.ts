export declare class ConstName {
    static readonly Const_Route: {
        Dashboard: string;
        Master: string;
    };
    static readonly Const_ListName: {
        Dashboard: string;
        Master: string;
    };
}
//# sourceMappingURL=Constants.d.ts.map