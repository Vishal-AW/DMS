declare const styles: {
    'tree-view': string;
    'node-name': string;
    'tree-node': string;
    'folder-icon': string;
    'toggle-button': string;
    grid: string;
    col2: string;
    'ms-Grid': string;
    row: string;
    col6: string;
    col10: string;
    col12: string;
    iFrameDialog: string;
    spinnerContainer: string;
    permissionDescription: string;
    table: string;
    'sub-btn': string;
    'can-btn': string;
};
export default styles;
//# sourceMappingURL=TreeView.module.scss.d.ts.map