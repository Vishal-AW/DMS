/// <reference types="react" />
declare const SearchComponent: (props: {
    context: any;
}) => JSX.Element;
export default SearchComponent;
//# sourceMappingURL=Search.d.ts.map