import React from 'react';
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface IUploadFileProps {
    isOpenUploadPanel: boolean;
    dismissUploadPanel: () => void;
    folderPath: string;
    libName: string;
    folderName: string;
    context: WebPartContext;
    files: any;
    folderObject: any;
}
declare function UploadFiles({ context, isOpenUploadPanel, dismissUploadPanel, folderPath, libName, folderName, files, folderObject }: IUploadFileProps): JSX.Element;
declare const _default: React.MemoExoticComponent<typeof UploadFiles>;
export default _default;
//# sourceMappingURL=UploadFile.d.ts.map