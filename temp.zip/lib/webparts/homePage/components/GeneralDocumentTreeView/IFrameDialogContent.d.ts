import * as React from "react";
export interface IIFrameDialogContentProps extends React.IframeHTMLAttributes<HTMLIFrameElement> {
    close: () => void;
    iframeOnLoad?: (iframe: HTMLIFrameElement) => void;
}
/**
 * IFrame Dialog content
 */
export declare const IFrameDialogContent: React.FunctionComponent<IIFrameDialogContentProps>;
//# sourceMappingURL=IFrameDialogContent.d.ts.map