/// <reference types="react" />
export default function TreeView({ props }: any): JSX.Element;
//# sourceMappingURL=TreeView.d.ts.map