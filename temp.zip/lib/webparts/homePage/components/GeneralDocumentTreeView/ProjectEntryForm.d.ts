import React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAdvanceProps {
    isOpen: boolean;
    dismissPanel: (value: boolean) => void;
    context: WebPartContext;
    LibraryDetails: any;
    admin: any;
}
declare const _default: React.NamedExoticComponent<IAdvanceProps>;
export default _default;
//# sourceMappingURL=ProjectEntryForm.d.ts.map