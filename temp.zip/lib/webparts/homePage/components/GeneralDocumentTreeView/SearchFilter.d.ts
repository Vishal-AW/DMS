/// <reference types="react" />
export default function SearchFilter({ props }: any): JSX.Element;
//# sourceMappingURL=SearchFilter.d.ts.map