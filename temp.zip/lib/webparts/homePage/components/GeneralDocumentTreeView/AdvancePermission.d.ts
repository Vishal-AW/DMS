import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAdvanceProps {
    isOpen: boolean;
    dismissPanel: () => void;
    context: WebPartContext;
    LibraryName: string;
    folderId: number;
}
declare const _default: React.NamedExoticComponent<IAdvanceProps>;
export default _default;
//# sourceMappingURL=AdvancePermission.d.ts.map