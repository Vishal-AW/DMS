import * as React from "react";
import { IDialogProps } from '@fluentui/react/lib/Dialog';
export interface IFrameDialogProps extends IDialogProps {
    url: string;
    iframeOnLoad?: (iframe: HTMLIFrameElement) => void;
    width: string;
    height: string;
    allowFullScreen?: boolean;
    allowTransparency?: boolean;
    marginHeight?: number;
    marginWidth?: number;
    name?: string;
    sandbox?: string;
    scrolling?: string;
    seamless?: boolean;
}
declare const IFrameDialog: React.FunctionComponent<IFrameDialogProps>;
export default IFrameDialog;
//# sourceMappingURL=IFrameDialog.d.ts.map