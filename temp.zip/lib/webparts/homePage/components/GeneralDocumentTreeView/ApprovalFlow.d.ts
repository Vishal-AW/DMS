import { WebPartContext } from "@microsoft/sp-webpart-base";
import React from 'react';
interface IApproval {
    context: WebPartContext;
    libraryName: string;
    userEmail: string;
}
declare const _default: React.NamedExoticComponent<IApproval>;
export default _default;
//# sourceMappingURL=ApprovalFlow.d.ts.map