declare const styles: {
    popupBody: string;
    popupHead: string;
    close: string;
    closeBtn: string;
    primaryButton: string;
};
export default styles;
//# sourceMappingURL=Common.module.scss.d.ts.map